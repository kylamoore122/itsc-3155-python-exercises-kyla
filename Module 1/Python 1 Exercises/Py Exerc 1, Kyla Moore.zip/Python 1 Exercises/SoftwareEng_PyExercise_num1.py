#Excercise 1
grade = ""
grade = input("Enter a grade from 0 to 100: ")

if (int(grade) >= 90):
    print("Your grade is an A")
elif (int(grade) >= 80):
    print("Your grade is an B")
elif (int(grade) >= 70):
    print("Your grade is an C")
elif (int(grade) >= 60):
    print("Your grade is an D")
elif (int(grade) >= 50):
    print("Your grade is an F")
