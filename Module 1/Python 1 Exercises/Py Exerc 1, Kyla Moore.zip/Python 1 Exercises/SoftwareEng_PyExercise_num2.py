#Excercise 2
#Needs string manipulation
stringA = ""
stringB = ""
stringA = input("Enter a string: ") 
stringB = input("Enter another string: ")

if(stringA < stringB):
    print(True)
else:
    print(False)
